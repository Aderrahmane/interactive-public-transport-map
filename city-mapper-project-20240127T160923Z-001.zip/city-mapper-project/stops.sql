create table table_stops1 ( stop_id text  , lat numeric , lng numeric, name text) 

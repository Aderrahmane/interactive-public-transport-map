CREATE TABLE walk(
    from_stop_I text,
    to_stop_I text,
    d text,
    d_walk NUMERIC
);
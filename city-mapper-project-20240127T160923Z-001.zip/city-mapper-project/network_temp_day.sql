CREATE TABLE network_temp (
    from_stop_I text,
    to_stop_I text,
    dep_time_ut text,
    arr_time_ut text,
    route_type text,
    trip_I text,
    seq text,
    route_I text
);
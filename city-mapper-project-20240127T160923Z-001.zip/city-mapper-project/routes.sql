CREATE TABLE routes (
    route_I text,
    route_name text,
    route_type text
)
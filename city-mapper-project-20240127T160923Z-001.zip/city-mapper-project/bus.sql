CREATE TABLE bus (
    from_stop_I text,
    to_stop_I text,
    d text,
    duration_avg NUMERIC ,
    n_vehicles NUMERIC ,
    route_I_counts text
);
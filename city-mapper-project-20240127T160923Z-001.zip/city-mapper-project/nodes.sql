CREATE TABLE nodes(
    stop_I text,
    lat NUMERIC,
    lon NUMERIC,
    name text
);